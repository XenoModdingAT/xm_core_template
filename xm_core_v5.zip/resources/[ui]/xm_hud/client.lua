CreateThread(function()
    while true do
        Wait(1000)
        SendNUIMessage({
            action = "update",
            health = GetEntityHealth(PlayerPedId())
        })
    end)
