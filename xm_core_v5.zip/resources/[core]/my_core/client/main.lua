RegisterNetEvent('xm:setData', function(data)
    print("Player Loaded", json.encode(data))
end)

AddEventHandler('playerSpawned', function()
    TriggerServerEvent('xm:playerLoaded')
end)
