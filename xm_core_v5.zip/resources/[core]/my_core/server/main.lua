XM = {}
XM.Players = {}

RegisterNetEvent('xm:playerLoaded', function()
    local src = source
    XM.Players[src] = {money = 1000, bank = 5000}
    TriggerClientEvent('xm:setData', src, XM.Players[src])
end)
